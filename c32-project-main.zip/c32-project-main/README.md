Features of this Stage 
The background of the project updates based on time.
The blocks vanish on coming in contact with the slingshot.
